//
//  CalendarCollectionViewCell.swift
//  T-Helper
//
//  Created by zjajgyy on 2016/11/28.
//  Copyright © 2016年 thelper. All rights reserved.
//

import UIKit

class CalendarCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var timeLabel: UILabel!
    
}
