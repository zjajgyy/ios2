//
//  ScheduleTask.swift
//  T-Helper
//
//  Created by 李鹏翔 on 2016/11/28.
//  Copyright © 2016年 thelper. All rights reserved.
//

import Foundation

class ScheduleTask {
    
    var detail : String!
    
    init(detail : String) {
        self.detail = detail
    }
    
}
