//
//  DateCollectionViewCell.swift
//  T-Helper
//
//  Created by zjajgyy on 2016/11/28.
//  Copyright © 2016年 thelper. All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var dateLabel: UILabel!
}
